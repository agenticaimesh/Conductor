# Conductor
Splits a big goal into small checked sub-goals, reuses proven modules, runs the rest through the Stack Builder worker, keeps job state. See PROJECT_SUMMARY.md.
Setup (once): create a NEW KV namespace and put its id in wrangler.toml; connect this repo to a new Cloudflare Worker named conductor; set secrets AUTH_TOKEN, BUILDER_URL, BUILDER_TOKEN, GROQ_API_KEY (and/or OPENROUTER_API_KEY).
Updates: upload Conductor-update.zip to the repo root, then Actions -> unpack-update -> Run workflow.
